/**
 * Comprehensive Tarot Card Dataset - Major Arcana & Celestial Archetypes
 */
window.TAROT_DECK = [
  {
    id: 0,
    name: "0. The Fool",
    arcana: "Major",
    numeral: "0",
    element: "Air",
    astrology: "Uranus",
    symbol: "feather",
    upright: {
      title: "New Beginnings, Innocence, Free Spirit",
      description: "The Fool represents the beginning of all journeys. You stand on the precipice of a profound leap of faith into the unknown. The universe invites you to trust the path ahead with childlike wonder and courage.",
      advice: "Take the leap. Leave fear behind and embrace spontaneous adventure."
    },
    reversed: {
      title: "Recklessness, Hesitation, Blind Risk",
      description: "You may be acting with disregard for consequences, or conversely, paralyzing hesitation is preventing you from starting your destiny.",
      advice: "Look carefully before stepping forward. Ground your vision in reality."
    }
  },
  {
    id: 1,
    name: "I. The Magician",
    arcana: "Major",
    numeral: "I",
    element: "Air",
    astrology: "Mercury",
    symbol: "infinity",
    upright: {
      title: "Manifestation, Power, Resourcefulness",
      description: "As above, so below. You possess all the four elemental tools—earth, air, fire, and water—to transform pure spiritual intention into tangible physical reality.",
      advice: "Align your will with action. You have everything you need right now to manifest your desired outcome."
    },
    reversed: {
      title: "Illusion, Untapped Potential, Manipulation",
      description: "You may be doubting your abilities, or using your gifts deceptively. Talents are remaining dormant due to lack of discipline.",
      advice: "Check your true motives and reconnect with honest purpose."
    }
  },
  {
    id: 2,
    name: "II. The High Priestess",
    arcana: "Major",
    numeral: "II",
    element: "Water",
    astrology: "The Moon",
    symbol: "crescent-moon",
    upright: {
      title: "Intuition, Sacred Knowledge, The Subconscious",
      description: "Guardian of the esoteric veil. The High Priestess calls you to turn your gaze inward. The answers you seek cannot be found through logic alone, but through inner whispering and dreams.",
      advice: "Trust your gut feeling and listen to your dreams. Still the chatter of the external world."
    },
    reversed: {
      title: "Secrets Revealed, Disconnected Intuition, Surface Living",
      description: "You are ignoring your inner voice or suppressing deep feelings. Hidden motives or withheld truths may be surfacing.",
      advice: "Slow down and withdraw from noise to rebuild harmony with your inner guidance."
    }
  },
  {
    id: 3,
    name: "III. The Empress",
    arcana: "Major",
    numeral: "III",
    element: "Earth",
    astrology: "Venus",
    symbol: "lotus",
    upright: {
      title: "Abundance, Nurturing, Divine Creation",
      description: "The divine mother and embodiment of flourishing life. The Empress brings fertile energy, artistic inspiration, sensual pleasure, and bountiful growth in love and projects.",
      advice: "Nurture what you love. Surround yourself with beauty, nature, and creative flow."
    },
    reversed: {
      title: "Creative Block, Emptiness, Over-dependence",
      description: "You may be feeling drained from over-giving to others while neglecting your own spiritual well-being.",
      advice: "Prioritize self-care and replenish your emotional cup first."
    }
  },
  {
    id: 4,
    name: "IV. The Emperor",
    arcana: "Major",
    numeral: "IV",
    element: "Fire",
    astrology: "Aries",
    symbol: "crown",
    upright: {
      title: "Authority, Structure, Strategic Leadership",
      description: "The architect of stability. The Emperor commands discipline, clear boundaries, and grounded authority to build an enduring kingdom of achievement.",
      advice: "Step into sovereign leadership. Establish clear boundaries and systematic plans."
    },
    reversed: {
      title: "Rigidity, Tyranny, Loss of Control",
      description: "Excessive control and micro-management are stifling vitality, or a lack of self-discipline is causing disarray.",
      advice: "Balance strength with compassion. Flexibility is the highest form of resilience."
    }
  },
  {
    id: 5,
    name: "V. The Hierophant",
    arcana: "Major",
    numeral: "V",
    element: "Earth",
    astrology: "Taurus",
    symbol: "sacred-keys",
    upright: {
      title: "Spiritual Wisdom, Tradition, Mentorship",
      description: "Keeper of ancient lineage and universal truths. The Hierophant invites you to seek timeless wisdom, sacred teachings, and guidance from trusted mentors.",
      advice: "Honor proven traditions and study deep wisdom before seeking radical shortcuts."
    },
    reversed: {
      title: "Rebellion, Dogma, Personal Beliefs",
      description: "Outdated traditions or rigid societal expectations no longer serve your soul. You are carving your own authentic philosophy.",
      advice: "Question the status quo and forge a spiritual path tailored to your soul."
    }
  },
  {
    id: 6,
    name: "VI. The Lovers",
    arcana: "Major",
    numeral: "VI",
    element: "Air",
    astrology: "Gemini",
    symbol: "dual-flame",
    upright: {
      title: "Sacred Union, Deep Harmony, Moral Choice",
      description: "A meeting of souls and unity of dualities. The Lovers denotes powerful romantic or spiritual alignment, and fundamental choices aligned with your deepest values.",
      advice: "Choose from love, never from fear. Harmonize intellect with heart."
    },
    reversed: {
      title: "Disharmony, Inner Conflict, Misalignment",
      description: "Values may be clashing in relationships or within yourself. You may be facing consequences of choices that compromise your integrity.",
      advice: "Realign with your core ethics before deciding on commitments."
    }
  },
  {
    id: 7,
    name: "VII. The Chariot",
    arcana: "Major",
    numeral: "VII",
    element: "Water",
    astrology: "Cancer",
    symbol: "star-wheel",
    upright: {
      title: "Triumph, Willpower, Focused Momentum",
      description: "Harnessing opposing forces to surge victoriously forward. The Chariot represents unstoppable momentum, laser focus, and victory through unwavering determination.",
      advice: "Maintain laser focus. Harness your passions and navigate contradictions toward your goal."
    },
    reversed: {
      title: "Lack of Direction, Aggression, Obstacles",
      description: "You may feel pulled in conflicting directions or are pushing so hard that burn-out threatens.",
      advice: "Regroup and adjust your steering. Brute force will not overcome subtle currents."
    }
  },
  {
    id: 8,
    name: "VIII. Strength",
    arcana: "Major",
    numeral: "VIII",
    element: "Fire",
    astrology: "Leo",
    symbol: "lion-heart",
    upright: {
      title: "Compassion, Gentle Power, Inner Fortitude",
      description: "True power does not dominate; it gentles the wild lion with patience and grace. Inner resilience, spiritual grace, and loving courage are your true armor.",
      advice: "Respond with patience, calmness, and heart-centered grace rather than anger."
    },
    reversed: {
      title: "Self-Doubt, Raw Impulse, Exhaustion",
      description: "A temporary dip in emotional endurance or giving in to fear and explosive reactions.",
      advice: "Be gentle with yourself. Forgive your imperfections and nourish your spirit."
    }
  },
  {
    id: 9,
    name: "IX. The Hermit",
    arcana: "Major",
    numeral: "IX",
    element: "Earth",
    astrology: "Virgo",
    symbol: "lantern",
    upright: {
      title: "Soul Searching, Solitude, Inner Illumination",
      description: "The seeker on the mountain holding aloft the lantern of truth. A period of sacred retreat to meditate, introspect, and discover your personal north star.",
      advice: "Step away from social frenzy. Solitude will reveal secrets that crowds obscure."
    },
    reversed: {
      title: "Isolation, Loneliness, Withdrawal",
      description: "Retreat has turned into unhealthy seclusion or hiding from necessary human connections.",
      advice: "Reach out your hand. Share your light and reconnect with companions."
    }
  },
  {
    id: 10,
    name: "X. Wheel of Fortune",
    arcana: "Major",
    numeral: "X",
    element: "Fire",
    astrology: "Jupiter",
    symbol: "cosmic-wheel",
    upright: {
      title: "Destiny, Cycles, Karmic Turning Points",
      description: "The celestial cycle turns in your favor. Synchronicity, unexpected opportunities, and karmic shifts are manifesting. Surrender to divine timing.",
      advice: "Seize unexpected blessings. Remember that all conditions are in motion, so cultivate gratitude."
    },
    reversed: {
      title: "Resistance to Change, Unlucky Delays",
      description: "Struggling against cosmic currents. What seems like misfortune is often a detour leading to your true destiny.",
      advice: "Release control over external events and focus on how you respond."
    }
  },
  {
    id: 11,
    name: "XI. Justice",
    arcana: "Major",
    numeral: "XI",
    element: "Air",
    astrology: "Libra",
    symbol: "scales",
    upright: {
      title: "Truth, Cause and Effect, Karmic Equilibrium",
      description: "The scales of universal truth. Justice brings clarity, honesty, and fair resolution. Every action creates an equivalent ripple in the cosmic tapestry.",
      advice: "Act with total honesty and objective clarity. Truth will prevail."
    },
    reversed: {
      title: "Unfairness, Denial of Responsibility, Dishonesty",
      description: "Avoiding accountability or feeling unfairly judged by circumstances.",
      advice: "Own your part with dignity. Seek balance rather than retaliation."
    }
  },
  {
    id: 12,
    name: "XII. The Hanged Man",
    arcana: "Major",
    numeral: "XII",
    element: "Water",
    astrology: "Neptune",
    symbol: "halo-tree",
    upright: {
      title: "Surrender, New Perspective, Enlightened Pause",
      description: "Suspended in stillness between worlds. Sometimes the only way forward is to stop fighting, flip your perspective upside down, and let revelation come to you.",
      advice: "Pause and let go of frantic efforts. A shift in perception will solve what action could not."
    },
    reversed: {
      title: "Martyrdom, Needless Stagnation, Resistance",
      description: "Sacrificing yourself without purpose or feeling stuck due to fear of change.",
      advice: "Stop waiting for permission to live your life. Release martyrdom."
    }
  },
  {
    id: 13,
    name: "XIII. Death",
    arcana: "Major",
    numeral: "XIII",
    element: "Water",
    astrology: "Scorpio",
    symbol: "phoenix-rose",
    upright: {
      title: "Profound Transformation, Metamorphosis, Rebirth",
      description: "The sacred closing of an old chapter so an extraordinary rebirth can blossom. The caterpillar dissolves to reveal the celestial winged spirit.",
      advice: "Let go gracefully of what is dying. Clear the soil for miraculous new growth."
    },
    reversed: {
      title: "Clinging to the Past, Fear of Renewal",
      description: "Holding onto expired relationships, habits, or jobs out of fear of the unknown.",
      advice: "The tighter you grip what has ended, the longer the pain lasts. Release it into the sacred fire."
    }
  },
  {
    id: 14,
    name: "XIV. Temperance",
    arcana: "Major",
    numeral: "XIV",
    element: "Fire",
    astrology: "Sagittarius",
    symbol: "golden-chalice",
    upright: {
      title: "Divine Alchemy, Balance, Patient Healing",
      description: "Blending polar opposites into gold. Temperance represents inner tranquility, patient moderation, and spiritual integration.",
      advice: "Find the middle path. Blend passion with composure and trust the healing timeline."
    },
    reversed: {
      title: "Imbalance, Excess, Discord",
      description: "Extremes, rushing, and overindulgence are throwing your physical or emotional equilibrium off balance.",
      advice: "Step back, cleanse your space, and restore grounding routines."
    }
  },
  {
    id: 15,
    name: "XV. The Devil",
    arcana: "Major",
    numeral: "XV",
    element: "Earth",
    astrology: "Capricorn",
    symbol: "broken-chain",
    upright: {
      title: "Shadow Self, Illusory Bondage, Material Attachment",
      description: "The chains that bind you are loose enough to slip off at any moment. The Devil exposes limiting beliefs, unhealthy attachments, and subconscious self-sabotage.",
      advice: "Recognize that your imprisonment is an illusion. Reclaim your sovereignty."
    },
    reversed: {
      title: "Breaking Free, Liberation, Overcoming Fear",
      description: "You are shedding toxic patterns and walking away from what once held you captive.",
      advice: "Step into your liberation without looking back."
    }
  },
  {
    id: 16,
    name: "XVI. The Tower",
    arcana: "Major",
    numeral: "XVI",
    element: "Fire",
    astrology: "Mars",
    symbol: "lightning-strike",
    upright: {
      title: "Sudden Revelation, Breakthrough, Collapse of Illusions",
      description: "Lightning strikes false foundations. The Tower shatters illusions to liberate your authentic spirit. What fell was not meant to withstand your true destiny.",
      advice: "Breathe through sudden changes. Rebuild only on bedrock truth."
    },
    reversed: {
      title: "Averting Disaster, Delaying the Inevitable",
      description: "Prolonging a crisis by avoiding confrontation, or recovering gradually after an upheaval.",
      advice: "Do not attempt to patch crumbling walls. Allow the false to crumble so the real can rise."
    }
  },
  {
    id: 17,
    name: "XVII. The Star",
    arcana: "Major",
    numeral: "XVII",
    element: "Air",
    astrology: "Aquarius",
    symbol: "eight-pointed-star",
    upright: {
      title: "Hope, Divine Guidance, Inspiration, Peace",
      description: "After the storm, the crystal sky clears to reveal the guiding star. Renewal, boundless serenity, and celestial blessings shower your life.",
      advice: "Have faith in the cosmic order. You are deeply protected and guided."
    },
    reversed: {
      title: "Despair, Lost Faith, Cynicism",
      description: "Feeling distant from your dreams or drained of spiritual inspiration.",
      advice: "Look up at the stars. Reignite your hope; help is nearer than you imagine."
    }
  },
  {
    id: 18,
    name: "XVIII. The Moon",
    arcana: "Major",
    numeral: "XVIII",
    element: "Water",
    astrology: "Pisces",
    symbol: "full-moon-path",
    upright: {
      title: "Mysteries, Subconscious Shadows, Vivid Dreams",
      description: "Walking the twilight path between wolves and hounds. Things are not entirely what they appear. Pay close attention to subtle cues, dreams, and hidden currents.",
      advice: "Do not rush into major contractual commitments until the light of day clarifies the landscape."
    },
    reversed: {
      title: "Clarity Dawning, Dispelling Illusions",
      description: "Anxiety and confusion are clearing. Secrets are revealed and fears dissolve.",
      advice: "Walk confidently into the clarity that is unfolding."
    }
  },
  {
    id: 19,
    name: "XIX. The Sun",
    arcana: "Major",
    numeral: "XIX",
    element: "Fire",
    astrology: "The Sun",
    symbol: "radiant-sun",
    upright: {
      title: "Radiant Joy, Vitality, Success, Clarity",
      description: "The most auspicious card in the deck. The golden rays of the Sun illuminate your path with supreme vitality, warmth, celebration, and victory.",
      advice: "Radiate your authenticity. Celebrate life and share your warmth boldly with the world."
    },
    reversed: {
      title: "Temporary Cloudiness, Delayed Celebration",
      description: "The sun is still shining behind a brief cloud. Optimism requires a small conscious effort.",
      advice: "Count your blessings and trust that light will penetrate the haze shortly."
    }
  },
  {
    id: 20,
    name: "XX. Judgement",
    arcana: "Major",
    numeral: "XX",
    element: "Fire",
    astrology: "Pluto",
    symbol: "celestial-horn",
    upright: {
      title: "Spiritual Calling, Rebirth, Absolution",
      description: "The celestial trumpet sounds, calling you to awaken to your true soul purpose. You are ready to step into a higher octave of existence.",
      advice: "Heed your calling without shame or hesitation. Forgive the past and rise."
    },
    reversed: {
      title: "Harsh Self-Criticism, Hesitation",
      description: "Judging yourself too harshly or ignoring an urgent spiritual wake-up call.",
      advice: "Release self-condemnation. Grant yourself absolution and answer your true calling."
    }
  },
  {
    id: 21,
    name: "XXI. The World",
    arcana: "Major",
    numeral: "XXI",
    element: "Earth",
    astrology: "Saturn",
    symbol: "ouroboros-wreath",
    upright: {
      title: "Wholeness, Completion, Cosmic Integration",
      description: "The grand cycle is fulfilled. The dancer stands centered in the universe, having mastered all lessons and integrated all archetypes into harmonious wholeness.",
      advice: "Celebrate your accomplishment. You have graduated to a sublime new plane of being."
    },
    reversed: {
      title: "Incomplete Cycles, Lingering Loose Ends",
      description: "You are on the verge of completion, but one final detail or lesson needs resolving.",
      advice: "Tie up the final threads so you can step cleanly into your next grand epoch."
    }
  }
];
